# Plan (clean-room, uso personal)

Alcance: ver canales, chat con emotes Twitch + 7TV, chat en modo "danmaku" arriba, calidad seleccionable.

Fuentes públicas: embed oficial de Twitch (JS API), IRC anónimo de chat (solo lectura), CDN de emotes, API pública de 7TV.
Sin APIs privadas, sin scraping, sin quitar anuncios.

Fuera de alcance: login, escribir en el chat, Helix (seguidos, directos en vivo), VODs, clips.

Arquitectura: una Activity Compose; un WebView con `docs/player.html`; `TwitchChat` (OkHttp WebSocket) → flujo de mensajes → lista debajo o capa danmaku encima del video.
