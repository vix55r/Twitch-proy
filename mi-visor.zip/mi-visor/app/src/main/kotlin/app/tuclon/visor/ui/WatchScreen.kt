package app.tuclon.visor.ui

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.tuclon.visor.BuildConfig
import app.tuclon.visor.chat.ChatMessage
import app.tuclon.visor.chat.TwitchChat
import app.tuclon.visor.data.Prefs
import okhttp3.OkHttpClient
import org.json.JSONObject

private const val LANES = 3
private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

private class Bridge(private val onQ: (String, List<Pair<String, String>>) -> Unit) {
    @JavascriptInterface
    fun onQualities(json: String) {
        try {
            val o = JSONObject(json)
            val arr = o.optJSONArray("list")
            val list = ArrayList<Pair<String, String>>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    list.add(e.optString("name") to e.optString("group"))
                }
            }
            val current = o.optString("current")
            Handler(Looper.getMainLooper()).post { onQ(current, list) }
        } catch (_: Exception) {
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WatchScreen(channel: String, prefs: Prefs, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val http = remember { OkHttpClient() }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var mode by remember { mutableStateOf(prefs.chatMode) }
    var fontSp by remember { mutableIntStateOf(prefs.fontSp) }
    var status by remember { mutableStateOf("") }
    var qualities by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var currentQ by remember { mutableStateOf(prefs.quality) }
    var showQ by remember { mutableStateOf(false) }
    var web by remember { mutableStateOf<WebView?>(null) }

    val messages = remember { mutableStateListOf<ChatMessage>() }
    val danmaku = remember { mutableStateListOf<DanmakuItem>() }
    val laneBusyUntil = remember { LongArray(LANES) }

    // En horizontal no hay espacio para el chat debajo: se pasa a modo "arriba".
    val effective = if (landscape && mode == "below") "top" else mode
    val effectiveNow by rememberUpdatedState(effective)

    // Mantener la pantalla encendida mientras se ve.
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    val chat = remember(channel) { TwitchChat(channel, prefs.use7tv, http, scope) }
    DisposableEffect(chat) {
        chat.start()
        onDispose { chat.stop() }
    }
    LaunchedEffect(chat) { chat.status.collect { status = it } }
    LaunchedEffect(chat) {
        chat.messages.collect { m ->
            messages.add(m)
            if (messages.size > 150) messages.removeAt(0)
            if (effectiveNow == "top") {
                val now = System.currentTimeMillis()
                val lane = (0 until LANES).firstOrNull { laneBusyUntil[it] <= now }
                if (lane != null && danmaku.size < 24) {
                    laneBusyUntil[lane] = now + 2500
                    danmaku.add(DanmakuItem(m, lane))
                }
            }
        }
    }
    LaunchedEffect(effective) { if (effective != "top") danmaku.clear() }

    val laneHeight = (fontSp * 1.9f).dp
    val pageUrl = BuildConfig.PLAYER_PAGE_URL

    fun selectQuality(group: String) {
        val g = group.filter { it.isLetterOrDigit() || it == '_' }
        prefs.quality = g
        currentQ = g
        web?.evaluateJavascript("window.setQuality && window.setQuality('$g')", null)
        showQ = false
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier.fillMaxWidth().then(
                if (landscape) Modifier.fillMaxHeight() else Modifier.aspectRatio(16f / 9f)
            )
        ) {
            if (pageUrl.isBlank()) {
                Text(
                    "Falta PLAYER_PAGE_URL. Mira el README (paso 3).",
                    color = Color.White,
                    modifier = Modifier.padding(16.dp),
                )
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            setBackgroundColor(android.graphics.Color.BLACK)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            if (prefs.desktopUa) settings.userAgentString = DESKTOP_UA
                            webChromeClient = WebChromeClient()
                            webViewClient = WebViewClient()
                            addJavascriptInterface(Bridge { cur, list ->
                                qualities = list
                                if (cur.isNotEmpty()) currentQ = cur
                            }, "Android")
                            loadUrl(
                                pageUrl + "?channel=" + Uri.encode(channel) +
                                    "&quality=" + Uri.encode(prefs.quality)
                            )
                        }
                    },
                    update = { web = it },
                    onRelease = { it.destroy() },
                )
            }
            if (effective == "top") {
                DanmakuLayer(
                    items = danmaku,
                    fontSp = fontSp,
                    laneHeight = laneHeight,
                    onDone = { id -> danmaku.removeAll { it.msg.id == id } },
                    modifier = Modifier.fillMaxWidth().height(laneHeight * LANES),
                )
            }
        }

        if (!landscape) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                TextButton(onClick = onBack) { Text("← Atrás") }
                TextButton(onClick = {
                    mode = when (mode) {
                        "below" -> "top"
                        "top" -> "hidden"
                        else -> "below"
                    }
                    prefs.chatMode = mode
                }) {
                    Text(
                        "Chat: " + when (mode) {
                            "below" -> "debajo"
                            "top" -> "arriba"
                            else -> "oculto"
                        }
                    )
                }
                TextButton(onClick = { showQ = true }) {
                    Text("Calidad: " + (if (currentQ == "chunked") "máxima" else currentQ))
                }
                TextButton(onClick = { fontSp = (fontSp - 2).coerceAtLeast(10); prefs.fontSp = fontSp }) { Text("A−") }
                TextButton(onClick = { fontSp = (fontSp + 2).coerceAtMost(28); prefs.fontSp = fontSp }) { Text("A+") }
            }
            Text(
                status,
                color = Color(0xFF8A8A8A),
                modifier = Modifier.padding(horizontal = 12.dp),
            )

            if (mode == "below") {
                val listState = rememberLazyListState()
                LaunchedEffect(messages.lastOrNull()?.id) {
                    if (messages.isNotEmpty()) listState.scrollToItem(messages.size - 1)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp),
                ) {
                    items(messages, key = { it.id }) { m ->
                        MessageText(m, fontSp, Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }
    }

    if (showQ) {
        AlertDialog(
            onDismissRequest = { showQ = false },
            confirmButton = { TextButton(onClick = { showQ = false }) { Text("Cerrar") } },
            title = { Text("Calidad") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = { selectQuality("auto") }) { Text("Auto") }
                    if (qualities.isEmpty()) {
                        Text("Las calidades del canal aparecen cuando empieza la reproducción.")
                    }
                    qualities.forEach { (name, group) ->
                        if (group != "auto") {
                            TextButton(onClick = { selectQuality(group) }) {
                                Text(name + if (group == currentQ) " ✓" else "")
                            }
                        }
                    }
                }
            },
        )
    }
}
