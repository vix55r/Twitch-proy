package app.tuclon.visor.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import app.tuclon.visor.chat.ChatMessage
import app.tuclon.visor.chat.Piece
import coil.compose.AsyncImage

private class Built(val text: AnnotatedString, val inline: Map<String, InlineTextContent>)

private fun build(msg: ChatMessage, fs: TextUnit): Built {
    val inline = HashMap<String, InlineTextContent>()
    val text = buildAnnotatedString {
        withStyle(SpanStyle(color = msg.color?.let { Color(it) } ?: Color(0xFFB8B8B8), fontWeight = FontWeight.Bold)) {
            append(msg.user)
        }
        append(": ")
        msg.pieces.forEachIndexed { i, p ->
            when (p) {
                is Piece.Word -> append(p.text)
                is Piece.Emote -> {
                    val key = "e$i"
                    appendInlineContent(key, p.name)
                    inline[key] = InlineTextContent(
                        Placeholder(fs * 1.7f, fs * 1.7f, PlaceholderVerticalAlign.TextCenter)
                    ) {
                        AsyncImage(model = p.url, contentDescription = p.name, modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
    return Built(text, inline)
}

/** Un mensaje de chat con emotes (Twitch y 7TV) en línea. */
@Composable
fun MessageText(msg: ChatMessage, fontSp: Int, modifier: Modifier = Modifier, shadow: Boolean = false) {
    val fs = fontSp.sp
    val built = remember(msg.id, fontSp) { build(msg, fs) }
    Text(
        text = built.text,
        inlineContent = built.inline,
        modifier = modifier,
        style = TextStyle(
            color = Color.White,
            fontSize = fs,
            shadow = if (shadow) Shadow(Color.Black, Offset(1.5f, 1.5f), 4f) else null,
        ),
    )
}

data class DanmakuItem(val msg: ChatMessage, val lane: Int)

/** Chat que corre de derecha a izquierda sobre el video. No captura toques. */
@Composable
fun DanmakuLayer(
    items: List<DanmakuItem>,
    fontSp: Int,
    laneHeight: Dp,
    onDone: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier.clipToBounds()) {
        val widthPx = with(LocalDensity.current) { maxWidth.toPx() }
        items.forEach { item ->
            key(item.msg.id) {
                Danmaku(item, widthPx, laneHeight, fontSp, onDone)
            }
        }
    }
}

@Composable
private fun Danmaku(item: DanmakuItem, containerPx: Float, laneHeight: Dp, fontSp: Int, onDone: (Long) -> Unit) {
    var w by remember { mutableIntStateOf(0) }
    val x = remember { Animatable(containerPx) }
    LaunchedEffect(w) {
        if (w > 0) {
            x.snapTo(containerPx)
            x.animateTo(-w.toFloat(), tween(durationMillis = 9000, easing = LinearEasing))
            onDone(item.msg.id)
        }
    }
    Box(
        Modifier
            .offset(y = laneHeight * item.lane)
            .wrapContentWidth(Alignment.Start, unbounded = true)
            .onSizeChanged { w = it.width }
            .graphicsLayer {
                translationX = x.value
                alpha = if (w > 0) 1f else 0f
            }
    ) {
        MessageText(item.msg, fontSp, shadow = true)
    }
}
