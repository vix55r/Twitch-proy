package app.tuclon.visor.data

import android.content.Context

/** Ajustes y canales guardados, solo en este teléfono. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var favorites: List<String>
        get() = sp.getString("favorites", "").orEmpty().split(',').filter { it.isNotBlank() }
        set(v) = sp.edit().putString("favorites", v.joinToString(",")).apply()

    /** "below" (debajo del video), "top" (arriba, en movimiento) u "hidden". */
    var chatMode: String
        get() = sp.getString("chatMode", "top").orEmpty()
        set(v) = sp.edit().putString("chatMode", v).apply()

    var use7tv: Boolean
        get() = sp.getBoolean("use7tv", true)
        set(v) = sp.edit().putBoolean("use7tv", v).apply()

    var fontSp: Int
        get() = sp.getInt("fontSp", 14)
        set(v) = sp.edit().putInt("fontSp", v).apply()

    /** Grupo de calidad de Twitch: "auto", "chunked" (fuente), "720p60"... */
    var quality: String
        get() = sp.getString("quality", "auto").orEmpty()
        set(v) = sp.edit().putString("quality", v).apply()

    /** Pedir la versión de escritorio de la página (puede desbloquear más calidades). */
    var desktopUa: Boolean
        get() = sp.getBoolean("desktopUa", true)
        set(v) = sp.edit().putBoolean("desktopUa", v).apply()
}
