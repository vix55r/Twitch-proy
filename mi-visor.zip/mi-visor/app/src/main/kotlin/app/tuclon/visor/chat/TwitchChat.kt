package app.tuclon.visor.chat

import android.graphics.Color as AndroidColor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * Lector del chat de Twitch por IRC anónimo (solo lectura, sin iniciar sesión).
 * Los emotes de Twitch vienen en las etiquetas del mensaje; los de 7TV se reemplazan por nombre.
 */
class TwitchChat(
    channelName: String,
    private val use7tv: Boolean,
    private val http: OkHttpClient,
    private val scope: CoroutineScope,
) {
    private val channel = channelName.lowercase().filter { it.isLetterOrDigit() || it == '_' }

    private val _messages = MutableSharedFlow<ChatMessage>(
        extraBufferCapacity = 128,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val messages: SharedFlow<ChatMessage> = _messages.asSharedFlow()

    private val _status = MutableStateFlow("Conectando al chat…")
    val status: StateFlow<String> = _status.asStateFlow()

    @Volatile private var emotes: Map<String, String> = emptyMap()
    @Volatile private var closed = false
    private var socket: WebSocket? = null
    private var sevenTvRequested = false
    private val ids = AtomicLong(0)

    fun start() {
        closed = false
        open()
    }

    fun stop() {
        closed = true
        socket?.close(1000, null)
        socket = null
    }

    private fun open() {
        if (closed) return
        val request = Request.Builder().url("wss://irc-ws.chat.twitch.tv:443").build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send("CAP REQ :twitch.tv/tags twitch.tv/commands")
                webSocket.send("PASS SCHMOOPIIE")
                webSocket.send("NICK justinfan${Random.nextInt(10000, 99999)}")
                webSocket.send("JOIN #$channel")
                _status.value = "Chat conectado"
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                for (line in text.split("\r\n")) {
                    if (line.isNotEmpty()) handleLine(webSocket, line)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = reconnect()

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = reconnect()
        })
    }

    private fun reconnect() {
        if (closed) return
        _status.value = "Reconectando al chat…"
        scope.launch {
            delay(3000)
            open()
        }
    }

    private fun handleLine(ws: WebSocket, line: String) {
        if (line.startsWith("PING")) {
            ws.send("PONG :tmi.twitch.tv")
            return
        }
        var rest = line
        var tags: Map<String, String> = emptyMap()
        if (rest.startsWith("@")) {
            val space = rest.indexOf(' ')
            if (space < 0) return
            tags = parseTags(rest.substring(1, space))
            rest = rest.substring(space + 1)
        }
        // ":nick!nick@nick.tmi.twitch.tv PRIVMSG #canal :texto"  /  ":tmi.twitch.tv ROOMSTATE #canal"
        val parts = rest.split(' ', limit = 4)
        when (parts.getOrNull(1)) {
            "ROOMSTATE" -> tags["room-id"]?.let { onRoomId(it) }
            "PRIVMSG" -> {
                val text = parts.getOrNull(3)?.removePrefix(":") ?: return
                onPrivMsg(tags, parts[0], text)
            }
        }
    }

    private fun parseTags(raw: String): Map<String, String> {
        val map = HashMap<String, String>()
        for (pair in raw.split(';')) {
            val eq = pair.indexOf('=')
            if (eq > 0) {
                map[pair.substring(0, eq)] = pair.substring(eq + 1).replace("\\s", " ").replace("\\:", ";")
            }
        }
        return map
    }

    private fun onRoomId(roomId: String) {
        if (!use7tv || sevenTvRequested) return
        sevenTvRequested = true
        scope.launch(Dispatchers.IO) {
            val loaded = SevenTv.load(http, roomId)
            if (loaded.isNotEmpty()) {
                emotes = loaded
                _status.value = "Chat conectado · 7TV: ${loaded.size} emotes"
            } else {
                _status.value = "Chat conectado · 7TV no disponible"
            }
        }
    }

    private fun onPrivMsg(tags: Map<String, String>, prefix: String, rawText: String) {
        var text = rawText
        if (text.startsWith("\u0001ACTION ")) {
            text = text.removePrefix("\u0001ACTION ").removeSuffix("\u0001")
        }
        val nick = prefix.removePrefix(":").substringBefore('!')
        val name = tags["display-name"]?.takeIf { it.isNotBlank() } ?: nick
        val color = tags["color"]
            ?.takeIf { it.startsWith("#") }
            ?.let { runCatching { AndroidColor.parseColor(it) }.getOrNull() }
        val pieces = buildPieces(text, tags["emotes"].orEmpty())
        _messages.tryEmit(ChatMessage(ids.incrementAndGet(), name, color, pieces))
    }

    /** Parte el texto en palabras y emotes. Los índices de Twitch cuentan puntos de código Unicode. */
    private fun buildPieces(text: String, emoteTag: String): List<Piece> {
        val cps = text.codePoints().toArray()

        // inicio -> (fin, id del emote de Twitch)
        val twitch = HashMap<Int, Pair<Int, String>>()
        if (emoteTag.isNotEmpty()) {
            for (group in emoteTag.split('/')) {
                val emoteId = group.substringBefore(':')
                for (range in group.substringAfter(':', "").split(',')) {
                    val s = range.substringBefore('-').toIntOrNull() ?: continue
                    val e = range.substringAfter('-', "").toIntOrNull() ?: continue
                    if (s >= 0 && e >= s && e < cps.size) twitch[s] = e to emoteId
                }
            }
        }

        val out = ArrayList<Piece>()
        val sb = StringBuilder()
        var i = 0
        while (i < cps.size) {
            val hit = twitch[i]
            if (hit != null) {
                flush(sb, out)
                val end = hit.first
                val name = String(cps, i, end - i + 1)
                out.add(Piece.Emote(name, "https://static-cdn.jtvnw.net/emoticons/v2/${hit.second}/default/dark/2.0"))
                i = end + 1
            } else {
                sb.appendCodePoint(cps[i])
                i++
            }
        }
        flush(sb, out)
        return out
    }

    private fun flush(sb: StringBuilder, out: MutableList<Piece>) {
        if (sb.isEmpty()) return
        val map = emotes
        val tokens = sb.toString().split(' ')
        tokens.forEachIndexed { idx, token ->
            if (token.isNotEmpty()) {
                val url = map[token]
                out.add(if (url != null) Piece.Emote(token, url) else Piece.Word(token))
            }
            if (idx < tokens.size - 1) out.add(Piece.Word(" "))
        }
        sb.setLength(0)
    }
}
