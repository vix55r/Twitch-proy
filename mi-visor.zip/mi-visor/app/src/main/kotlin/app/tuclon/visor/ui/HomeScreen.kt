package app.tuclon.visor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.tuclon.visor.data.Prefs

private fun clean(s: String) = s.trim().lowercase().filter { it.isLetterOrDigit() || it == '_' }

@Composable
fun HomeScreen(prefs: Prefs, onWatch: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var favs by remember { mutableStateOf(prefs.favorites) }
    var mode by remember { mutableStateOf(prefs.chatMode) }
    var use7tv by remember { mutableStateOf(prefs.use7tv) }
    var desktop by remember { mutableStateOf(prefs.desktopUa) }
    var quality by remember { mutableStateOf(prefs.quality) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E10))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Mi Visor", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Canal de Twitch") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { clean(text).takeIf { it.isNotEmpty() }?.let(onWatch) }) { Text("Ver") }
            TextButton(onClick = {
                val c = clean(text)
                if (c.isNotEmpty() && c !in favs) {
                    favs = favs + c
                    prefs.favorites = favs
                }
            }) { Text("Guardar canal") }
        }

        if (favs.isNotEmpty()) {
            Text("Mis canales", color = Color(0xFFB8B8B8))
            favs.forEach { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onWatch(f) }, modifier = Modifier.weight(1f)) {
                        Text(f, modifier = Modifier.fillMaxWidth())
                    }
                    TextButton(onClick = {
                        favs = favs - f
                        prefs.favorites = favs
                    }) { Text("✕") }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Chat", color = Color(0xFFB8B8B8))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("below" to "Debajo", "top" to "Arriba", "hidden" to "Oculto").forEach { (k, label) ->
                FilterChip(selected = mode == k, onClick = { mode = k; prefs.chatMode = k }, label = { Text(label) })
            }
        }

        Text("Calidad inicial", color = Color(0xFFB8B8B8))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "Auto", "chunked" to "Máxima").forEach { (k, label) ->
                FilterChip(selected = quality == k, onClick = { quality = k; prefs.quality = k }, label = { Text(label) })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = use7tv, onClick = { use7tv = !use7tv; prefs.use7tv = use7tv }, label = { Text("Emotes 7TV") })
            FilterChip(selected = desktop, onClick = { desktop = !desktop; prefs.desktopUa = desktop }, label = { Text("Página de escritorio") })
        }
    }
}
