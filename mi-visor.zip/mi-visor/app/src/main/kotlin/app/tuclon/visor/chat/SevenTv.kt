package app.tuclon.visor.chat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

/**
 * Emotes de 7TV (API pública, sin clave). Solo lectura.
 * Usa la API v3. Si 7TV la cambia o la apaga, esto devuelve vacío y el chat sigue sin emotes de 7TV.
 */
object SevenTv {

    suspend fun load(http: OkHttpClient, twitchUserId: String): Map<String, String> =
        withContext(Dispatchers.IO) {
            val out = HashMap<String, String>()
            val id = twitchUserId.filter { it.isDigit() }

            get(http, "https://7tv.io/v3/emote-sets/global")?.let { body ->
                runCatching { addEmotes(JSONObject(body).optJSONArray("emotes"), out) }
            }
            if (id.isNotEmpty()) {
                // El set del canal va después para que sus emotes ganen sobre los globales.
                get(http, "https://7tv.io/v3/users/twitch/$id")?.let { body ->
                    runCatching {
                        addEmotes(JSONObject(body).optJSONObject("emote_set")?.optJSONArray("emotes"), out)
                    }
                }
            }
            out
        }

    private fun get(http: OkHttpClient, url: String): String? =
        try {
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.isSuccessful) r.body?.string() else null
            }
        } catch (_: Exception) {
            null
        }

    private fun addEmotes(arr: JSONArray?, out: MutableMap<String, String>) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val id = e.optString("id")
            val name = e.optString("name")
            if (id.isNotEmpty() && name.isNotEmpty()) {
                out[name] = "https://cdn.7tv.app/emote/$id/2x.webp"
            }
        }
    }
}
