package app.tuclon.visor.chat

sealed interface Piece {
    data class Word(val text: String) : Piece
    data class Emote(val name: String, val url: String) : Piece
}

data class ChatMessage(
    val id: Long,
    val user: String,
    val color: Int?,
    val pieces: List<Piece>,
)
