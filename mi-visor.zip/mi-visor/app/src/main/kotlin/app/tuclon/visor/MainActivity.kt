package app.tuclon.visor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import app.tuclon.visor.data.Prefs
import app.tuclon.visor.ui.HomeScreen
import app.tuclon.visor.ui.WatchScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    var channel by remember { mutableStateOf<String?>(null) }
                    BackHandler(enabled = channel != null) { channel = null }
                    val c = channel
                    if (c == null) {
                        HomeScreen(prefs) { channel = it }
                    } else {
                        WatchScreen(c, prefs) { channel = null }
                    }
                }
            }
        }
    }
}
