# Mi Visor (Twitch para Android, uso personal)

App para el Honor X6b: ver canales de Twitch con el reproductor oficial incrustado,
chat con emotes de Twitch y 7TV, y modo de chat que corre por arriba del video.

## Cómo sacar el APK (sin Android Studio)

1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. **Settings → Pages**: Source = *Deploy from a branch*, branch `main`, carpeta `/docs`.
   Tu página quedará en `https://USUARIO.github.io/REPO/player.html`.
3. **Settings → Secrets and variables → Actions → Variables → New repository variable**:
   nombre `PLAYER_PAGE_URL`, valor la URL del paso 2.
4. **Actions → Build APK → Run workflow**. Al terminar, descarga el artefacto `mi-visor-apk`.
5. Descomprime e instala `app-debug.apk` en el teléfono (permite "instalar apps desconocidas").

Si cambias la variable, vuelve a ejecutar el workflow.

## Por qué hay una página en GitHub Pages

El reproductor incrustado de Twitch solo funciona dentro de un dominio declarado en `parent`.
Una app móvil no tiene dominio, así que `docs/player.html` hace de página anfitriona.

## Límites a tener en cuenta

- 1440p solo existe si el canal lo emite; la pantalla del X6b es 720×1612, así que no lo verás más nítido que 720p.
  El botón "Calidad" lista lo que ofrece el canal.
- El cambio de calidad por script puede fallar durante anuncios.
- Emotes 7TV: usa la API v3; si 7TV la cambia, el chat sigue sin emotes de 7TV.
- Sin inicio de sesión de Twitch: no hay chat para escribir, ni seguidos, ni suscripciones.
- El código no se ha compilado aquí: si Actions falla, copia el error y lo corrijo.
